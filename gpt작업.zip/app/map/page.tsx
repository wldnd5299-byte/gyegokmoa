import {
  MapPin,
} from "lucide-react";

import PlaceMapExplorer, {
  type PlaceMapItem,
} from "@/components/PlaceMapExplorer";

import {
  getPublishedPlaces,
} from "@/lib/places";

export default async function MapPage() {
  const places =
    await getPublishedPlaces();

  const mapPlaces: PlaceMapItem[] =
    places
      .filter(
        (place) =>
          typeof place.latitude === "number" &&
          typeof place.longitude === "number" &&
          (
            place.place_type === "attraction" ||
            place.place_type === "restaurant" ||
            place.place_type === "cafe" ||
            place.place_type === "accommodation"
          )
      )
      .map((place) => ({
        id: place.id,
        name: place.name,
        slug: place.slug,
        place_type:
          place.place_type as
            PlaceMapItem["place_type"],
        region:
          place.region || "",
        city:
          place.city || "",
        latitude:
          place.latitude as number,
        longitude:
          place.longitude as number,
        image_url:
          place.image_url || null,
        summary:
          place.summary || null,
      }));

  return (
    <main className="places-map-page">
      <section className="places-map-compact-header">
        <div className="container">
          <span className="places-map-compact-eyebrow">
            <MapPin
              size={15}
              aria-hidden="true"
            />
            전국 부모님 나들이 지도
          </span>

          <div className="places-map-compact-heading">
            <div>
              <h1>
                지도에서 장소 찾기
              </h1>

              <p>
                지역이나 장소를 검색하고 부모님과 함께 가기 좋은
                곳을 찾아보세요.
              </p>
            </div>
          </div>
        </div>
      </section>

      <PlaceMapExplorer
        places={mapPlaces}
      />
    </main>
  );
}
