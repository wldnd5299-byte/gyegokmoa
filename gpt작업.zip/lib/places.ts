import { createClient } from "@/lib/supabase/server";

export type PlaceType =
  | "attraction"
  | "restaurant"
  | "cafe"
  | "accommodation";

export type Place = {
  id: number;
  name: string;
  slug: string;

  place_type: PlaceType;

  region: string;
  city: string;
  address: string;

  latitude: number | null;
  longitude: number | null;

  phone: string | null;
  website_url: string | null;

  summary: string;
  description: string | null;

  parent_recommendation: string | null;

  business_hours: string | null;
  admission_fee: string | null;

  parking: boolean | null;
  restroom: boolean | null;

  environment_type:
    | "indoor"
    | "outdoor"
    | "mixed"
    | null;

  image_url: string | null;

  tags: string[];

  is_published: boolean;

  recommendation_score: number;

  is_editor_pick: boolean;
  is_partner: boolean;

  created_at: string;
  updated_at: string;
};

export async function getPublishedPlaces(): Promise<Place[]> {
  const supabase = await createClient();

  const {
    data,
    error,
  } = await supabase
    .from("places")
    .select(`
      id,
      name,
      slug,
      place_type,
      region,
      city,
      address,
      latitude,
      longitude,
      phone,
      website_url,
      summary,
      description,
      parent_recommendation,
      business_hours,
      admission_fee,
      parking,
      restroom,
      environment_type,
      image_url,
      tags,
      is_published,
      recommendation_score,
      is_editor_pick,
      is_partner,
      created_at,
      updated_at
    `)
    .eq("is_published", true)
    .order("recommendation_score", {
      ascending: false,
    })
    .order("created_at", {
      ascending: false,
    });

  if (error) {
    console.error(
      "공개 장소 불러오기 실패:",
      error
    );

    return [];
  }

  return (data ?? []) as Place[];
}

export async function getPublishedPlacesByType(
  placeType: PlaceType,
  limit = 6
): Promise<Place[]> {
  const supabase = await createClient();

  const {
    data,
    error,
  } = await supabase
    .from("places")
    .select(`
      id,
      name,
      slug,
      place_type,
      region,
      city,
      address,
      latitude,
      longitude,
      phone,
      website_url,
      summary,
      description,
      parent_recommendation,
      business_hours,
      admission_fee,
      parking,
      restroom,
      environment_type,
      image_url,
      tags,
      is_published,
      recommendation_score,
      is_editor_pick,
      is_partner,
      created_at,
      updated_at
    `)
    .eq("is_published", true)
    .eq("place_type", placeType)
    .order("recommendation_score", {
      ascending: false,
    })
    .order("created_at", {
      ascending: false,
    })
    .limit(limit);

  if (error) {
    console.error(
      `${placeType} 장소 불러오기 실패:`,
      error
    );

    return [];
  }

  return (data ?? []) as Place[];
}

export async function getPublishedPlacesByRegion(
  region: string
): Promise<Place[]> {
  const supabase = await createClient();

  const {
    data,
    error,
  } = await supabase
    .from("places")
    .select(`
      id,
      name,
      slug,
      place_type,
      region,
      city,
      address,
      latitude,
      longitude,
      phone,
      website_url,
      summary,
      description,
      parent_recommendation,
      business_hours,
      admission_fee,
      parking,
      restroom,
      environment_type,
      image_url,
      tags,
      is_published,
      recommendation_score,
      is_editor_pick,
      is_partner,
      created_at,
      updated_at
    `)
    .eq("is_published", true)
    .eq("region", region)
    .order("recommendation_score", {
      ascending: false,
    })
    .order("created_at", {
      ascending: false,
    });

  if (error) {
    console.error(
      `${region} 장소 불러오기 실패:`,
      error
    );

    return [];
  }

  return (data ?? []) as Place[];
}

export async function getPublishedPlaceBySlug(
  slug: string
): Promise<Place | null> {
  const supabase = await createClient();

  const {
    data,
    error,
  } = await supabase
    .from("places")
    .select(`
      id,
      name,
      slug,
      place_type,
      region,
      city,
      address,
      latitude,
      longitude,
      phone,
      website_url,
      summary,
      description,
      parent_recommendation,
      business_hours,
      admission_fee,
      parking,
      restroom,
      environment_type,
      image_url,
      tags,
      is_published,
      recommendation_score,
      is_editor_pick,
      is_partner,
      created_at,
      updated_at
    `)
    .eq("slug", slug)
    .eq("is_published", true)
    .maybeSingle();

  if (error) {
    console.error(
      "장소 상세정보 불러오기 실패:",
      error
    );

    return null;
  }

  return data as Place | null;
}